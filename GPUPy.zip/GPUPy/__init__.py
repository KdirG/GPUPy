
"""
GPUPy: GPU Accelerated Numerical Methods Library
"""

__version__ = "0.1.0"


from .src.numerical_methods import *