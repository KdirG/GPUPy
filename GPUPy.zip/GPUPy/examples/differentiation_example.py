# differentiation_example.py
