# integration_example.py
