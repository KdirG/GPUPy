# optimization_example.py
