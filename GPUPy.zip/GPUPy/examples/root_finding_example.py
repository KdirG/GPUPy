# root_finding_example.py
